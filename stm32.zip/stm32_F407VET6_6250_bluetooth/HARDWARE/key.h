#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
#include "system.h"

void KEY_Init(void);
uint8_t click(void);
void Delay_ms(void);
uint8_t click_N_Double (uint8_t time);
uint8_t click_N_Double_MPU6050 (uint8_t time);
uint8_t Long_Press(void);

/*--------KEY control pin--------*/
#define KEY_PORT	GPIOE
#define KEY_PIN		GPIO_Pin_0
#define KEY			PEin(0) 
/*----------------------------------*/

#endif 
