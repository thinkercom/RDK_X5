#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"
#include "system.h"
#define Battery_Ch    8 //Battery voltage, ADC channel 8 //��ص�ѹ��ADCͨ��8
#define Potentiometer 9  //Potentiometer, ADC channel 9 //��λ����ADCͨ��9
void Adc_Init(void);
void  Adc_POWER_Init(void);
uint16_t Get_Adc(uint8_t ch);
uint16_t Get_Adc2(uint8_t ch);
float Get_battery_volt(void) ;
uint16_t Get_adc_Average(uint8_t chn, uint8_t times);
extern double Voltage,Voltage_Count,Voltage_All; 	
#endif 


