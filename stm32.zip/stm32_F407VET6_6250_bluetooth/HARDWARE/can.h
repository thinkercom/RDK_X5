#ifndef __CAN_H
#define __CAN_H	 
#include "sys.h"	    
#include "system.h"
 
//CAN1 receives RX0 interrupt enablement
//CAN1����RX0�ж�ʹ��
#define CAN1_RX0_INT_ENABLE	1	//0, not enabling;1, can make //0,��ʹ��; 1,ʹ��								    		

uint8_t CAN1_Mode_Init(uint8_t tsjw,uint8_t tbs2,uint8_t tbs1,uint16_t brp,uint8_t mode);
uint8_t CAN1_Tx_Msg(uint32_t id,uint8_t ide,uint8_t rtr,uint8_t len,uint8_t *dat);		
uint8_t CAN1_Msg_Pend(uint8_t fifox);							
void CAN1_Rx_Msg(uint8_t fifox,uint32_t *id,uint8_t *ide,uint8_t *rtr,uint8_t *len,uint8_t *dat);
uint8_t CAN1_Tx_Staus(uint8_t mbox);  								
uint8_t CAN1_Send_Msg(uint8_t* msg,uint8_t len);						
uint8_t CAN1_Receive_Msg(uint8_t *buf);						

uint8_t CAN1_Send_MsgTEST(uint8_t* msg,uint8_t len);
uint8_t CAN1_Send_Num(uint32_t id,uint8_t* msg);

void can_data_transition(void);

#endif

















